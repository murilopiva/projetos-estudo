import os
import pandas as pd 
import numpy as np 
import flask
from joblib import load
from flask import Flask, render_template, request

model = load('iris_model.joblib')
app = Flask(__name__)


@app.route('/')
def index():
    return flask.render_template('index.html')
 
def predictSpecies(sample):
    sample = np.array(sample).reshape(1,4)
    
    return model.predict(sample)

@app.route('/predict', methods = ['POST'])
def result():

    if request.method == 'POST':
        sample = request.form.to_dict()
        sample = list(sample.values())
        sample = list(map(float, sample))
        
        result = predictSpecies(sample)
        
        prediction = str(result)
        
        return render_template("predict.html", prediction = prediction)

if __name__ == "__main__":
    app.run(debug=True)